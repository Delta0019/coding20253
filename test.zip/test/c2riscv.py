import subprocess
import os

def compile_to_riscv(c_file, output_file):
    riscv_gcc = "riscv64-unknown-elf-gcc"

    try:
        subprocess.run([
            riscv_gcc,
            "-S",
            "-o", output_file,
            c_file
        ], check=True)
        print(f"RISC-V 汇编已生成: {output_file}")
    except subprocess.CalledProcessError as e:
        print("编译失败:", e)

def main():
    c_file = "./code.c"
    asm_output = "riscv.s"
    final_output = "riscv.txt"

    compile_to_riscv(c_file, asm_output)

    if os.path.exists(asm_output):
        with open(asm_output, "r") as f_in, open(final_output, "w") as f_out:
            f_out.write(f_in.read())
        print("结果已写入 riscv.txt")

if __name__ == "__main__":
    main()
