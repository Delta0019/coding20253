// code.c
int sum(int a, int b)
{
    return a + b;
}

int main()
{
    int result = sum(5, 7);
    return result;
}
